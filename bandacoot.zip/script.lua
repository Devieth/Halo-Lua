api_version = "1.0.0"

skip = false

function register_callbacks()
	register_callback(cb['PLAYER_KILLS'], "player_kills")
	register_callback(cb['HIT_DETECT'], "hit_sound")
end

function display(message, name, sound, low_priority)
	low_priority = low_priority or true
	if message ~= nil then
		hud_message(message)
	end
	queue_audio(sound, low_priority)
	if name ~= nil then
		display_medal(name)
	end
end

function hit_sound(event)
	if event ~= nil then
		skip = true
		display(nil, nil, "audio/coot2.mp3", false)
	else
		if skip ~= true then
			display(nil, nil, "audio/coot1.mp3", false)
		else
			skip = false
		end
	end
end

function player_kills(event, killer, victim, player, timestamp)
	if(killer == player) then
		hit_sound("kill")
	end
end
